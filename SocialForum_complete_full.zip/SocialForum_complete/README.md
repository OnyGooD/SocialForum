# SocialForum – profiloldallal kibővített verzió

Ez a csomag a teljes projektet tartalmazza, nem csak a változásokat.

## Új funkciók
- publikus profiloldal: `/u/:username`
- kattintható felhasználónevek
- profilon külön láthatók:
  - a felhasználó által létrehozott témák
  - a felhasználó hozzászólásai, és hogy melyik témához szólt hozzá

## Futtatás

### Backend
```bash
cd forum-backend-sqlite
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux / macOS:
source venv/bin/activate

pip install -r requirements.txt
copy .env.example .env   # Windows
# vagy
cp .env.example .env     # Linux / macOS

python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

### Frontend
Új terminálban:
```bash
cd forum-frontend
npm install
copy .env.example .env   # Windows
# vagy
cp .env.example .env     # Linux / macOS

npm run dev
```

## Címek
- Frontend: http://localhost:3000
- Backend: http://127.0.0.1:8000

## Profil megnyitása
Példa:
- http://localhost:3000/u/felhasznalonev
