from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/auth/',     include('users.urls')),
    path('api/users/',    include('users.urls_profile')),
    path('api/posts/',    include('posts.urls')),
    path('api/comments/', include('comments.urls')),
]
