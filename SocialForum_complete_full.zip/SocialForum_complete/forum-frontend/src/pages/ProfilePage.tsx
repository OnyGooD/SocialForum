import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import api from '../api/axios'

type ProfilePost = {
  id: number
  title: string
  content: string
  comment_count: number
  created_at: string
}

type ProfileComment = {
  id: number
  content: string
  created_at: string
  post_id: number
  post_title: string
}

type ProfileData = {
  id: number
  username: string
  date_joined: string
  posts: ProfilePost[]
  comments: ProfileComment[]
}

function timeAgo(dateStr: string) {
  const diff = (Date.now() - new Date(dateStr).getTime()) / 1000
  if (diff < 60) return `${Math.floor(diff)} mp`
  if (diff < 3600) return `${Math.floor(diff / 60)} p`
  if (diff < 86400) return `${Math.floor(diff / 3600)} ó`
  return `${Math.floor(diff / 86400)} n`
}

function stringToColor(str = '') {
  const colors = ['#ff4500', '#7c3aed', '#0ea5e9', '#10b981', '#f59e0b', '#ec4899']
  let hash = 0
  for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash)
  return colors[Math.abs(hash) % colors.length]
}

export default function ProfilePage() {
  const { username } = useParams()
  const [profile, setProfile] = useState<ProfileData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!username) return

    setLoading(true)
    api.get(`/users/${username}/`)
      .then((res) => setProfile(res.data))
      .catch(() => setProfile(null))
      .finally(() => setLoading(false))
  }, [username])

  if (loading) return <div className="spinner" />

  if (!profile) {
    return (
      <div style={{ maxWidth: 900, margin: '0 auto', padding: '32px 20px', color: '#e8e8ec' }}>
        A profil nem található.
      </div>
    )
  }

  return (
    <div style={{ maxWidth: 1000, margin: '0 auto', padding: '32px 20px' }}>
      <div
        style={{
          background: '#17171a',
          border: '1px solid #2a2a30',
          borderRadius: 14,
          padding: 24,
          marginBottom: 24,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: '50%',
              background: stringToColor(profile.username),
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 22,
              fontWeight: 700,
              color: '#fff',
            }}
          >
            {profile.username?.[0]?.toUpperCase()}
          </div>

          <div>
            <h1
              style={{
                margin: 0,
                color: '#e8e8ec',
                fontFamily: 'Syne, sans-serif',
                fontSize: 28,
              }}
            >
              u/{profile.username}
            </h1>
            <p style={{ margin: '6px 0 0', color: '#6b6b78', fontSize: 14 }}>
              Regisztrált: {new Date(profile.date_joined).toLocaleDateString('hu-HU')}
            </p>
          </div>
        </div>
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 20,
          alignItems: 'start',
        }}
      >
        <section
          style={{
            background: '#17171a',
            border: '1px solid #2a2a30',
            borderRadius: 12,
            padding: 20,
          }}
        >
          <h2 style={{ color: '#e8e8ec', marginTop: 0, marginBottom: 16 }}>
            Létrehozott témák
          </h2>

          {profile.posts.length === 0 ? (
            <p style={{ color: '#6b6b78' }}>Még nem hozott létre témát.</p>
          ) : (
            profile.posts.map((post) => (
              <div
                key={post.id}
                style={{
                  padding: '14px 0',
                  borderBottom: '1px solid #2a2a30',
                }}
              >
                <Link
                  to={`/post/${post.id}`}
                  style={{
                    color: '#e8e8ec',
                    fontWeight: 700,
                    fontSize: 16,
                    textDecoration: 'none',
                  }}
                >
                  {post.title}
                </Link>

                {post.content && (
                  <p style={{ color: '#8c8c99', fontSize: 14, lineHeight: 1.55, marginTop: 8 }}>
                    {post.content}
                  </p>
                )}

                <p style={{ color: '#6b6b78', fontSize: 13, marginTop: 8 }}>
                  💬 {post.comment_count} hozzászólás · {timeAgo(post.created_at)}
                </p>
              </div>
            ))
          )}
        </section>

        <section
          style={{
            background: '#17171a',
            border: '1px solid #2a2a30',
            borderRadius: 12,
            padding: 20,
          }}
        >
          <h2 style={{ color: '#e8e8ec', marginTop: 0, marginBottom: 16 }}>
            Hozzászólásai
          </h2>

          {profile.comments.length === 0 ? (
            <p style={{ color: '#6b6b78' }}>Még nem szólt hozzá témákhoz.</p>
          ) : (
            profile.comments.map((comment) => (
              <div
                key={comment.id}
                style={{
                  padding: '14px 0',
                  borderBottom: '1px solid #2a2a30',
                }}
              >
                <p style={{ color: '#c8c8d0', fontSize: 14, lineHeight: 1.6, margin: 0 }}>
                  {comment.content}
                </p>

                <p style={{ color: '#6b6b78', fontSize: 13, marginTop: 8 }}>
                  ehhez a témához:{' '}
                  <Link
                    to={`/post/${comment.post_id}`}
                    style={{ color: '#ff4500', textDecoration: 'none', fontWeight: 600 }}
                  >
                    {comment.post_title}
                  </Link>{' '}
                  · {timeAgo(comment.created_at)}
                </p>
              </div>
            ))
          )}
        </section>
      </div>
    </div>
  )
}
